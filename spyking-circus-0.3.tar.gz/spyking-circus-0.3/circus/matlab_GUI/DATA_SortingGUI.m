classdef DATA_SortingGUI < handle
    %DATA_GUI Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        lines
        
        elecMx
        elecMy
    
        %selected
        
        zoom_coef
        
        MaxdiffX
        MaxdiffY
        
        fullX
        marginX
        fullY
        marginY
        
%         propose_ij
%         
%         propose_c
%         propose_i2_r = 0
%         propose_i3_r = 0
%         
        last_neu_i_click = 1
    end
    
    methods
    end
    
end

